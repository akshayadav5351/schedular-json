"pkg": {
    "scripts": "build/**/*.js",
    "assets": "views/**/*"
  }
  "main": "index.js"